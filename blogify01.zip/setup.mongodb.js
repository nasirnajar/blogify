use('ecommerce');

db.products.find().pretty();